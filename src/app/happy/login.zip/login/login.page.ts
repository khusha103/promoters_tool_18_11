import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  username: string ='';
  password: string= '';
  error: string | null = null;
  constructor(private authservice:AuthService,private router:Router, private toastController: ToastController) { }

  ngOnInit() {
  }

  async onLogin() {
    this.authservice.happylogin(this.username, this.password).subscribe(
      async (response) => {
        if (response.error) {
          this.error = response.message;
          await this.showToast(this.error || 'An unknown error occurred.'); // Show toast with the error message
        } else {
          // Handle successful login
          console.log('User:', response.user);

          localStorage.setItem('isLoggedIn', 'true'); // Set login status
          localStorage.setItem('userId', response.user.user_id); // Store user ID
          localStorage.setItem('isAdmin', response.user.isAdmin);
          localStorage.setItem('isSuperAdmin', response.user.isSuperAdmin);

          // Navigate to the home page
          this.router.navigate(['/home']);
        }
      },
      async (error) => {
        // Handle error
        console.error('Login error:', error);
        await this.showToast('Login failed. Please try again.'); // Show toast for failed login
      }
    );
  }

  // Method to show toast
  async showToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000, // Duration in milliseconds
      position: 'bottom', // Position of the toast
      color: 'danger', // Optional: color of the toast
    });
    await toast.present(); // Show the toast
  }
}
